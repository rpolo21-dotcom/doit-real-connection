'use strict';
const webpush = require('web-push');
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function json(res, status, body) {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  return res.status(status).json(body);
}
async function requestJson(url, headers) {
  const response = await fetch(url, { headers });
  const text = await response.text();
  let body;
  try { body = text ? JSON.parse(text) : null; } catch (_) { body = null; }
  if (!response.ok) throw new Error(`Supabase request failed (${response.status}).`);
  return body;
}
module.exports = async function handler(req, res) {
  if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return json(res, 405, { error: 'Method not allowed' }); }
  const authorization = req.headers.authorization || '';
  const token = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
  if (!token || token.length > 6000) return json(res, 401, { error: 'Sesión no válida.' });
  const { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, DOIT_PUSH_GATEWAY_SECRET, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT } = process.env;
  if (![SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, DOIT_PUSH_GATEWAY_SECRET, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT].every(Boolean)) {
    return json(res, 503, { error: 'El servicio de notificaciones no está configurado.' });
  }
  try {
    const base = SUPABASE_URL.replace(/\/$/, '');
    const commonHeaders = { apikey: SUPABASE_PUBLISHABLE_KEY, Authorization: `Bearer ${token}` };
    const me = await requestJson(`${base}/auth/v1/user`, commonHeaders);
    if (!me?.id || !uuidPattern.test(me.id)) return json(res, 401, { error: 'Sesión no válida.' });
    const messageId = String(req.body?.message_id || '');
    if (!uuidPattern.test(messageId)) return json(res, 400, { error: 'message_id no válido.' });
    const messageUrl = new URL(`${base}/rest/v1/messages`);
    messageUrl.searchParams.set('id', `eq.${messageId}`);
    messageUrl.searchParams.set('select', 'id,conversation_id,sender_id');
    messageUrl.searchParams.set('limit', '1');
    const messages = await requestJson(messageUrl.toString(), commonHeaders);
    const message = Array.isArray(messages) ? messages[0] : null;
    if (!message || message.sender_id !== me.id || !uuidPattern.test(message.conversation_id)) return json(res, 404, { error: 'Mensaje no encontrado.' });
    const membersUrl = new URL(`${base}/rest/v1/conversation_members`);
    membersUrl.searchParams.set('conversation_id', `eq.${message.conversation_id}`);
    membersUrl.searchParams.set('user_id', `neq.${me.id}`);
    membersUrl.searchParams.set('select', 'user_id');
    const peers = await requestJson(membersUrl.toString(), commonHeaders);
    const peerIds = [...new Set((Array.isArray(peers) ? peers : []).map(x => x.user_id).filter(x => uuidPattern.test(x)))];
    if (!peerIds.length) return json(res, 200, { sent: 0, reason: 'no-recipient' });
    const subscriptionsUrl = new URL(`${base}/rest/v1/push_subscriptions`);
    subscriptionsUrl.searchParams.set('user_id', `in.(${peerIds.join(',')})`);
    subscriptionsUrl.searchParams.set('select', 'endpoint,p256dh,auth');
    const subscriptions = await requestJson(subscriptionsUrl.toString(), {
      ...commonHeaders,
      'x-doit-conversation-id': message.conversation_id,
      'x-doit-push-gateway-secret': DOIT_PUSH_GATEWAY_SECRET
    });
    if (!Array.isArray(subscriptions) || subscriptions.length === 0) return json(res, 200, { sent: 0, reason: 'no-subscriptions' });
    webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
    const payload = JSON.stringify({
      title: 'Nuevo mensaje en Doit',
      body: 'Tienes un mensaje nuevo. Abre Doit para leerlo.',
      url: `/?conversation=${encodeURIComponent(message.conversation_id)}`,
      tag: `doit-${message.conversation_id}`
    });
    const results = await Promise.allSettled(subscriptions.map(subscription =>
      webpush.sendNotification({ endpoint: subscription.endpoint, keys: { p256dh: subscription.p256dh, auth: subscription.auth } }, payload, { TTL: 90 })
    ));
    const sent = results.filter(x => x.status === 'fulfilled').length;
    return json(res, 200, { sent, failed: results.length - sent });
  } catch (error) {
    console.error('Doit push delivery failed:', error?.message || 'unknown error');
    return json(res, 502, { error: 'No se pudo enviar la notificación.' });
  }
};
