// Only public Supabase browser configuration and the public Web Push VAPID key.
// Never expose SUPABASE_SECRET_KEYS, service_role, VAPID_PRIVATE_KEY or the push gateway secret.
module.exports = function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  if (req.method !== 'GET') { res.setHeader('Allow', 'GET'); return res.status(405).json({ error: 'Method not allowed' }); }
  const supabaseUrl = process.env.SUPABASE_URL;
  const supabasePublishableKey = process.env.SUPABASE_PUBLISHABLE_KEY;
  const pushPublicKey = process.env.VAPID_PUBLIC_KEY;
  const pushReady = Boolean(pushPublicKey && process.env.VAPID_PRIVATE_KEY && process.env.DOIT_PUSH_GATEWAY_SECRET);
  if (!supabaseUrl || !supabasePublishableKey) return res.status(503).json({ error: 'Supabase no está configurado.' });
  try { const parsed = new URL(supabaseUrl); if (parsed.protocol !== 'https:' || !parsed.hostname.endsWith('.supabase.co')) return res.status(500).json({ error: 'SUPABASE_URL no tiene un formato válido.' }); }
  catch (_) { return res.status(500).json({ error: 'SUPABASE_URL no tiene un formato válido.' }); }
  return res.status(200).json({ supabaseUrl, supabasePublishableKey, pushReady, pushPublicKey: pushReady ? pushPublicKey : null });
};
