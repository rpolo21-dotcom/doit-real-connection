'use strict';

let sb = null;
let config = null;
let user = null;
let profile = null;
let events = [];
let groups = [];
let groupMembers = [];
let attendees = [];
let conversations = [];
let conversationMembers = [];
let directory = new Map();
let chatMessages = [];
let activeConversationId = null;
let activeChannel = null;
let globalChannel = null;
let serviceWorkerRegistration = null;
let deferredInstallPrompt = null;
let loginMode = false;
let toastTimer = null;
let searchTimer = null;
let pushEnabled = false;
let profilePreferences = null;
let nearbyPeople = [];
let friendships = [];
let friendProfiles = new Map();
let agendaView = 'month';
let agendaDate = new Date();
let eventInvite = null;

const $ = (id) => document.getElementById(id);
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[char]));

function toast(message) {
  $('toast').textContent = message;
  $('toast').classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $('toast').classList.remove('show'), 3200);
}

function setTab(tab) {
  document.querySelectorAll('.nav-button').forEach((button) => {
    button.classList.toggle('active', button.dataset.tab === tab);
  });
  document.querySelectorAll('.panel').forEach((panel) => {
    panel.classList.toggle('active', panel.id === `${tab}Panel`);
  });
  const titles = {
    feed: 'Próximos encuentros', plans: 'Tu agenda', create: 'Crear un plan',
    groups: 'Tus comunidades', chat: 'Mensajes privados', profile: 'Tu perfil'
  };
  $('screenTitle').textContent = titles[tab] || 'Doit';
  if (tab === 'chat' && user) loadChats().catch((error) => toast(error.message));
  if (tab === 'plans') renderAgenda();
  if (tab === 'profile') renderFriends();
}

function isAppInstalled() {
  return window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;
}

function isIOSDevice() {
  return /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

function installInstructions() {
  if (isIOSDevice()) return 'En Safari, toca Compartir (el cuadro con la flecha hacia arriba) y elige “Añadir a pantalla de inicio”. Luego abre DoIT desde el icono.';
  if (/android/i.test(navigator.userAgent)) return 'En Chrome, abre el menú ⋮ y elige “Instalar aplicación” o “Añadir a pantalla de inicio”.';
  return 'En el navegador, abre el menú de la barra de direcciones y elige “Instalar DoIT” o “Instalar aplicación”, si aparece.';
}

function updateInstallCard() {
  const card = $('installCard');
  if (!card) return;
  if (isAppInstalled()) { card.classList.add('hidden'); return; }
  card.classList.remove('hidden');
  $('installAppBtn').textContent = deferredInstallPrompt ? 'Instalar DoIT' : 'Cómo instalar';
}

async function handleInstallClick() {
  if (deferredInstallPrompt) {
    const promptEvent = deferredInstallPrompt;
    deferredInstallPrompt = null;
    try {
      await promptEvent.prompt();
      const choice = await promptEvent.userChoice;
      if (choice?.outcome === 'accepted') toast('DoIT se está instalando en tu dispositivo.');
      else toast('Puedes instalar DoIT cuando quieras desde el menú del navegador.');
    } catch (_) {
      $('installHelp').textContent = installInstructions();
      $('installHelp').classList.remove('hidden');
    }
    updateInstallCard();
    return;
  }
  const help = $('installHelp');
  help.textContent = installInstructions();
  help.classList.toggle('hidden');
}

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  deferredInstallPrompt = event;
  updateInstallCard();
});
window.addEventListener('appinstalled', () => {
  deferredInstallPrompt = null;
  $('installCard')?.classList.add('hidden');
  toast('DoIT quedó instalada.');
});

function updatePushOnboarding() {
  const card = $('pushOnboarding');
  if (!card || !user) return;
  const denied = !('Notification' in window) || Notification.permission === 'denied';
  const dismissed = sessionStorage.getItem('doit-push-onboarding-dismissed') === '1';
  const available = config?.pushReady === true && 'PushManager' in window && 'serviceWorker' in navigator;
  card.classList.toggle('hidden', !available || pushEnabled || denied || dismissed);
  if (denied) $('pushToggle').title = 'Permiso bloqueado. Cámbialo en los ajustes del navegador.';
}

function showAuth() {
  $('appScreen').classList.add('hidden');
  $('authScreen').classList.remove('hidden');
  $('cloudState').textContent = 'Conectado a Doit';
  const params = new URL(location.href).searchParams;
  $('eventInviteAuthHint')?.classList.toggle('hidden', !(params.get('event') || params.get('invite')));
}

function showApp() {
  $('authScreen').classList.add('hidden');
  $('appScreen').classList.remove('hidden');
  $('cloudState').textContent = 'En línea';
  $('welcome').textContent = `Hola, ${profile?.full_name || user?.email || 'bienvenido'}`;
  $('todayLabel').textContent = new Intl.DateTimeFormat('es-CO', { dateStyle: 'medium' }).format(new Date());
  $('profileEmail').textContent = user?.email || '';
  $('profileName').value = profile?.full_name || '';
  $('usageLimit').value = profile?.usage_limit_mins || 25;
  $('limitValue').textContent = `${$('usageLimit').value} min`;
  $('profileCountry').value = profilePreferences?.country_code || '';
  $('profileCity').value = profilePreferences?.city || '';
  $('profileHobbies').value = (profilePreferences?.hobbies || []).join(', ');
  $('profileWeeklyTime').value = String(profilePreferences?.weekly_time_minutes || 180);
  $('profileDiscoverable').checked = profilePreferences?.discoverable === true;
  document.querySelectorAll('input[name="profileInterest"]').forEach((input) => {
    input.checked = (profilePreferences?.interests || []).includes(input.value);
  });
  const avatar = $('avatarPreview');
  avatar.innerHTML = profile?.avatar_url && /^https:\/\//i.test(profile.avatar_url)
    ? `<img src="${escapeHTML(profile.avatar_url)}" alt="Foto de perfil">`
    : escapeHTML((profile?.full_name || 'D').trim().charAt(0).toUpperCase());
  const inviteParams = new URL(location.href).searchParams;
  $('eventInviteAuthHint').classList.toggle('hidden', !(inviteParams.get('event') || inviteParams.get('invite')));
}

function prettyDate(value) {
  return new Intl.DateTimeFormat('es-CO', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
}

function emptyState(message) {
  return `<div class="empty-state">${escapeHTML(message)}</div>`;
}

async function loadData() {
  if (!user) return;
  const results = await Promise.all([
    sb.from('profiles').select('id,full_name,bio,avatar_url,usage_limit_mins').eq('id', user.id).maybeSingle(),
    sb.from('profile_preferences').select('user_id,interests,hobbies,country_code,country,region,city,weekly_time_minutes,discoverable,onboarding_completed').eq('user_id', user.id).maybeSingle(),
    sb.from('events').select('id,creator_id,group_id,title,description,date_time,location,category').gte('date_time', new Date(Date.now() - 180 * 86400000).toISOString()).order('date_time', { ascending: true }).limit(500),
    sb.from('groups').select('id,creator_id,name,description,category,icon,country_code,city,interest_tags').order('created_at', { ascending: false }),
    sb.from('group_members').select('group_id,user_id'),
    sb.from('event_attendees').select('event_id,user_id,status'),
    sb.from('friendships').select('id,requester_id,addressee_id,status,source_event_id,created_at').or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`)
  ]);
  for (const result of results) if (result.error) throw result.error;
  profile = results[0].data;
  if (!profile) throw new Error('No se encontró el perfil de esta cuenta. Cierra sesión y vuelve a entrar.');
  profilePreferences = results[1].data;
  if (!profilePreferences) {
    const meta = user.user_metadata || {};
    const interests = Array.isArray(meta.interests) ? meta.interests.filter((v) => typeof v === 'string').slice(0, 20) : [];
    const hobbies = Array.isArray(meta.hobbies) ? meta.hobbies.filter((v) => typeof v === 'string').slice(0, 20) : [];
    const initialPreferences = {
      user_id: user.id,
      interests,
      hobbies,
      country_code: typeof meta.country_code === 'string' ? meta.country_code : null,
      country: typeof meta.country === 'string' ? meta.country : null,
      city: typeof meta.city === 'string' ? meta.city.trim() : null,
      weekly_time_minutes: Number(meta.weekly_time_minutes) || 180,
      discoverable: meta.discoverable === true,
      onboarding_completed: !!(meta.country_code && meta.city && interests.length)
    };
    const { data, error } = await sb.from('profile_preferences').upsert(initialPreferences, { onConflict: 'user_id' })
      .select('user_id,interests,hobbies,country_code,country,region,city,weekly_time_minutes,discoverable,onboarding_completed').single();
    if (error) throw error;
    profilePreferences = data;
  }
  events = results[2].data || [];
  groups = results[3].data || [];
  groupMembers = results[4].data || [];
  attendees = results[5].data || [];
  friendships = results[6].data || [];
  await syncProfileDiscovery(profilePreferences);
  await loadNearbyPeople();
  await loadFriendProfiles();
  showApp();
  renderAll();
  await loadChats();
  await subscribeGlobalActivity();
  await updatePushButton();
  await processEventInvite();
  const requestedConversation = new URL(location.href).searchParams.get('conversation');
  if (requestedConversation && uuidPattern.test(requestedConversation)) {
    const member = conversationMembers.some((row) => row.conversation_id === requestedConversation && row.user_id === user.id);
    if (member) {
      setTab('chat');
      await openConversation(requestedConversation);
    }
  }
}

async function syncProfileDiscovery(preferences = profilePreferences) {
  if (!user) return;
  const optedIn = preferences?.discoverable === true && /^[A-Z]{2}$/.test(preferences.country_code || '') && !!String(preferences.city || '').trim();
  if (!optedIn) {
    const { error } = await sb.from('profile_discovery').delete().eq('user_id', user.id);
    if (error) throw error;
    return;
  }
  const { error } = await sb.from('profile_discovery').upsert({
    user_id: user.id,
    country_code: preferences.country_code,
    city: String(preferences.city).trim(),
    interests: Array.isArray(preferences.interests) ? preferences.interests : [],
    is_discoverable: true,
    updated_at: new Date().toISOString()
  }, { onConflict: 'user_id' });
  if (error) throw error;
}

async function loadNearbyPeople() {
  nearbyPeople = [];
  if (!profilePreferences?.country_code || !String(profilePreferences.city || '').trim()) return;
  const { data, error } = await sb.from('profile_discovery')
    .select('user_id,interests,country_code,city')
    .eq('country_code', profilePreferences.country_code)
    .eq('city', String(profilePreferences.city || '').trim())
    .eq('is_discoverable', true)
    .limit(500);
  if (error) throw error;
  nearbyPeople = (data || []).filter((row) => row.user_id !== user.id);
}

async function loadFriendProfiles() {
  const ids = [...new Set(friendships.map((row) => row.requester_id === user.id ? row.addressee_id : row.requester_id))];
  friendProfiles = new Map();
  if (!ids.length) return;
  const { data, error } = await sb.from('profiles').select('id,full_name,avatar_url,bio').in('id', ids);
  if (error) throw error;
  friendProfiles = new Map((data || []).map((row) => [row.id, row]));
}

function renderAll() {
  renderEvents();
  renderGroups();
  renderFriends();
  const groupSelect = $('eventGroup');
  const myGroupIds = new Set(groupMembers.filter((row) => row.user_id === user.id).map((row) => row.group_id));
  groupSelect.innerHTML = '<option value="">Plan abierto</option>' + groups
    .filter((group) => myGroupIds.has(group.id))
    .map((group) => `<option value="${escapeHTML(group.id)}">${escapeHTML(group.name)}</option>`).join('');
}

async function getEventShareUrl(event) {
  const { data: token, error } = await sb.rpc('create_event_invite', { p_event_id: event.id });
  if (error) throw error;
  if (!uuidPattern.test(String(token || ''))) throw new Error('No se pudo generar un enlace seguro para este plan.');
  const url = new URL(location.origin + location.pathname);
  url.searchParams.set('invite', token);
  return url.toString();
}

function eventCard(event, agenda = false) {
  const myResponse = attendees.find((row) => row.event_id === event.id && row.user_id === user.id);
  const going = attendees.filter((row) => row.event_id === event.id && row.status === 'voy').length;
  const category = ({ sport: 'Deporte', cafe: 'Café y charla', study: 'Estudio', food: 'Salida', outdoor: 'Aire libre' })[event.category] || 'Encuentro';
  const responseLabel = myResponse?.status === 'voy' ? 'Voy' : myResponse?.status === 'quizas' ? 'Quizás' : myResponse?.status === 'no' ? 'No voy' : 'Sin respuesta';
  return `<article class="item-card">
    <div class="card-top"><span class="tag">${category}</span><span class="card-meta">${going} van</span></div>
    <h3>${escapeHTML(event.title)}</h3>
    <p>${escapeHTML(event.description || 'Un encuentro para compartir en la vida real.')}</p>
    <div class="card-meta">▦ ${escapeHTML(prettyDate(event.date_time))}<br>⌖ ${escapeHTML(event.location)}</div>
    ${agenda ? `<p class="card-meta">Tu respuesta: <strong>${responseLabel}</strong></p>` : `<div class="card-actions">
      <button class="small-btn primary" data-action="rsvp" data-id="${escapeHTML(event.id)}" data-status="voy">Voy</button>
      <button class="small-btn" data-action="rsvp" data-id="${escapeHTML(event.id)}" data-status="quizas">Quizás</button>
      <button class="small-btn" data-action="rsvp" data-id="${escapeHTML(event.id)}" data-status="no">No voy</button>
    </div>`}
    <div class="card-actions"><button class="small-btn" data-action="copy-event-link" data-id="${escapeHTML(event.id)}">Copiar enlace de invitación</button></div>
  </article>`;
}

function getMyAgendaEvents() {
  return events.filter((event) => attendees.some((row) => row.event_id === event.id && row.user_id === user.id && ['voy', 'quizas'].includes(row.status)));
}

function localDateKey(date) {
  const d = new Date(date);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function parseDateKey(value) {
  const [y, m, d] = value.split('-').map(Number);
  return new Date(y, m - 1, d);
}

function moveDate(date, days) {
  const next = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  next.setDate(next.getDate() + days);
  return next;
}

function weekStart(date) {
  const copy = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const day = (copy.getDay() + 6) % 7;
  copy.setDate(copy.getDate() - day);
  return copy;
}

function agendaTitle(start, end) {
  const fmt = new Intl.DateTimeFormat('es-CO', { month: 'long', year: 'numeric' });
  if (agendaView === 'day') return new Intl.DateTimeFormat('es-CO', { dateStyle: 'full' }).format(start);
  if (agendaView === 'week') return `${new Intl.DateTimeFormat('es-CO', { day: 'numeric', month: 'short' }).format(start)} – ${new Intl.DateTimeFormat('es-CO', { day: 'numeric', month: 'short', year: 'numeric' }).format(moveDate(end, -1))}`;
  return fmt.format(start);
}

function renderAgenda() {
  if (!$('agendaCalendar') || !user) return;
  const eventsForMe = getMyAgendaEvents();
  const todayKey = localDateKey(new Date());
  let periodStart;
  let periodEnd;
  let html = '';
  if (agendaView === 'month') {
    const first = new Date(agendaDate.getFullYear(), agendaDate.getMonth(), 1);
    const gridStart = weekStart(first);
    periodStart = gridStart;
    periodEnd = moveDate(gridStart, 42);
    const weekdays = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
    html = `<div class="month-grid">${weekdays.map((day) => `<div class="month-weekday">${day}</div>`).join('')}`;
    for (let i = 0; i < 42; i++) {
      const day = moveDate(gridStart, i);
      const key = localDateKey(day);
      const dayEvents = eventsForMe.filter((item) => localDateKey(item.date_time) === key);
      const classes = ['month-day', day.getMonth() !== agendaDate.getMonth() ? 'outside' : '', key === localDateKey(agendaDate) ? 'selected' : '', key === todayKey ? 'today' : ''].filter(Boolean).join(' ');
      html += `<button type="button" class="${classes}" data-agenda-date="${key}"><span class="day-number">${day.getDate()}</span><span class="day-event-dots">${dayEvents.slice(0, 3).map((item) => `<span class="day-event-chip">${escapeHTML(item.title)}</span>`).join('')}${dayEvents.length > 3 ? `<span class="card-meta">+${dayEvents.length - 3}</span>` : ''}</span></button>`;
    }
    html += '</div>';
  } else if (agendaView === 'week') {
    periodStart = weekStart(agendaDate);
    periodEnd = moveDate(periodStart, 7);
    html = '<div class="week-agenda">';
    for (let i = 0; i < 7; i++) {
      const day = moveDate(periodStart, i);
      const key = localDateKey(day);
      const dayEvents = eventsForMe.filter((item) => localDateKey(item.date_time) === key);
      html += `<section class="week-day"><h4>${new Intl.DateTimeFormat('es-CO', { weekday: 'long' }).format(day)}</h4><div class="week-date">${new Intl.DateTimeFormat('es-CO', { day: 'numeric', month: 'short' }).format(day)}</div>${dayEvents.length ? dayEvents.map((item) => `<button class="week-event" type="button" data-agenda-date="${key}">${escapeHTML(new Intl.DateTimeFormat('es-CO', { hour: '2-digit', minute: '2-digit' }).format(new Date(item.date_time)))} · ${escapeHTML(item.title)}</button>`).join('') : '<span class="card-meta">Sin planes</span>'}</section>`;
    }
    html += '</div>';
  } else {
    periodStart = new Date(agendaDate.getFullYear(), agendaDate.getMonth(), agendaDate.getDate());
    periodEnd = moveDate(periodStart, 1);
    const dayEvents = eventsForMe.filter((item) => localDateKey(item.date_time) === localDateKey(periodStart));
    html = `<div class="day-agenda">${dayEvents.length ? dayEvents.map((item) => `<div class="week-day"><h4>${escapeHTML(new Intl.DateTimeFormat('es-CO', { hour: '2-digit', minute: '2-digit' }).format(new Date(item.date_time)))}</h4><div class="week-date">${escapeHTML(item.location)}</div><div>${escapeHTML(item.title)}</div></div>`).join('') : emptyState('No tienes actividades agendadas para este día.')}</div>`;
  }
  $('agendaHeading').textContent = agendaTitle(periodStart, periodEnd);
  $('agendaCalendar').innerHTML = html;
  document.querySelectorAll('[data-agenda-view]').forEach((button) => button.classList.toggle('active', button.dataset.agendaView === agendaView));
  const inPeriod = eventsForMe.filter((item) => {
    const time = new Date(item.date_time).getTime();
    return time >= periodStart.getTime() && time < periodEnd.getTime();
  }).sort((a, b) => new Date(a.date_time) - new Date(b.date_time));
  $('agendaEvents').innerHTML = inPeriod.length ? inPeriod.map((item) => eventCard(item, true)).join('') : emptyState('No tienes actividades en este periodo. Únete a un plan o crea uno nuevo.');
}

function renderEvents() {
  const futureEvents = events.filter((event) => new Date(event.date_time) >= new Date());
  $('feedList').innerHTML = futureEvents.length ? futureEvents.map((event) => eventCard(event)).join('') : emptyState('Aún no hay planes. Crea el primero y pon la vida en movimiento.');
  renderAgenda();
}

function groupCard(group, recommended = false) {
  const count = groupMembers.filter((row) => row.group_id === group.id).length;
  const joined = groupMembers.some((row) => row.group_id === group.id && row.user_id === user.id);
  const locationText = [group.city, profileCountryName(group.country_code)].filter(Boolean).join(' · ');
  return `<article class="item-card"><div class="card-top"><span class="tag">${recommended ? 'Recomendado cerca' : 'Comunidad'}</span><span class="card-meta">${count} miembros</span></div>
    <h3>${escapeHTML(group.name)}</h3><p>${escapeHTML(group.description || 'Personas reuniéndose alrededor de un interés común.')}</p>
    ${locationText ? `<p class="card-meta">⌖ ${escapeHTML(locationText)}</p>` : ''}
    ${Array.isArray(group.interest_tags) && group.interest_tags.length ? `<p class="card-meta">Intereses: ${escapeHTML(group.interest_tags.join(', '))}</p>` : ''}
    <div class="card-actions"><button class="small-btn ${joined ? '' : 'primary'}" data-action="join-group" data-id="${escapeHTML(group.id)}" ${joined ? 'disabled' : ''}>${joined ? 'Ya perteneces' : 'Unirme al grupo'}</button></div></article>`;
}

function profileCountryName(code) {
  return ({ CO: 'Colombia', MX: 'México', AR: 'Argentina', CL: 'Chile', PE: 'Perú', EC: 'Ecuador', VE: 'Venezuela', PA: 'Panamá', CR: 'Costa Rica', UY: 'Uruguay', BR: 'Brasil', ES: 'España', US: 'Estados Unidos', DO: 'Rep. Dominicana', GT: 'Guatemala', BO: 'Bolivia', PY: 'Paraguay' })[code] || '';
}

function renderGroups() {
  const ownIds = new Set(groupMembers.filter((row) => row.user_id === user.id).map((row) => row.group_id));
  const localIds = new Set(nearbyPeople.map((row) => row.user_id));
  const interests = new Set(profilePreferences?.interests || []);
  const recommendations = groups.filter((group) => {
    if (ownIds.has(group.id) || !profilePreferences?.country_code || group.country_code !== profilePreferences.country_code) return false;
    const sameCity = profilePreferences.city && group.city?.toLocaleLowerCase('es') === profilePreferences.city.toLocaleLowerCase('es');
    const hasLocalMembers = groupMembers.some((row) => row.group_id === group.id && localIds.has(row.user_id));
    return !!sameCity && hasLocalMembers;
  }).map((group) => {
    const localMembers = groupMembers.filter((row) => row.group_id === group.id && localIds.has(row.user_id)).length;
    const matchingTags = (group.interest_tags || []).filter((tag) => [...interests].some((interest) => interest.toLocaleLowerCase('es') === String(tag).toLocaleLowerCase('es'))).length;
    return { group, score: localMembers * 3 + matchingTags * 2 };
  }).sort((a, b) => b.score - a.score).map((row) => row.group).slice(0, 6);
  $('localDiscoverySummary').textContent = !profilePreferences?.country_code || !String(profilePreferences.city || '').trim()
    ? 'Añade tu país y ciudad en el perfil para ver comunidades cercanas.'
    : `${nearbyPeople.length} personas de tu ciudad han elegido aparecer en el descubrimiento local. Te mostramos grupos en los que participan y que coinciden con tus intereses. ${profilePreferences.discoverable === true ? 'Tu perfil también puede aparecer en recomendaciones.' : 'Tu perfil permanece fuera del descubrimiento; puedes explorar sin hacerte visible.'}`;
  $('localGroupsList').innerHTML = recommendations.length ? recommendations.map((group) => groupCard(group, true)).join('') : emptyState('Todavía no encontramos grupos locales compatibles. Puedes crear uno e invitar a otras personas.');
  $('groupsList').innerHTML = groups.length ? groups.map((group) => groupCard(group, false)).join('') : emptyState('Todavía no hay comunidades. Puedes crear la primera.');
}

function renderFriends() {
  if (!$('friendRequests')) return;
  const incoming = friendships.filter((row) => row.addressee_id === user.id && row.status === 'pending');
  const accepted = friendships.filter((row) => row.status === 'accepted');
  $('friendRequests').innerHTML = incoming.length ? incoming.map((row) => {
    const peer = friendProfiles.get(row.requester_id);
    return `<div class="friend-row"><div class="friend-row-main">${avatarMarkup(peer)}<span><strong>${escapeHTML(peer?.full_name || 'Usuario DoIT')}</strong><small>Quiere conectar contigo</small></span></div><div class="friend-actions"><button class="small-btn primary" data-action="accept-friend" data-id="${escapeHTML(row.id)}">Aceptar</button><button class="small-btn" data-action="reject-friend" data-id="${escapeHTML(row.id)}">Ahora no</button></div></div>`;
  }).join('') : emptyState('No tienes solicitudes pendientes.');
  $('friendsList').innerHTML = accepted.length ? accepted.map((row) => {
    const peerId = row.requester_id === user.id ? row.addressee_id : row.requester_id;
    const peer = friendProfiles.get(peerId);
    return `<div class="friend-row"><div class="friend-row-main">${avatarMarkup(peer)}<span><strong>${escapeHTML(peer?.full_name || 'Usuario DoIT')}</strong><small>Amigos en DoIT</small></span></div></div>`;
  }).join('') : emptyState('Cuando acepten una solicitud, tus amigos aparecerán aquí.');
}

async function refreshFriendships() {
  const { data, error } = await sb.from('friendships').select('id,requester_id,addressee_id,status,source_event_id,created_at').or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`);
  if (error) throw error;
  friendships = data || [];
  await loadFriendProfiles();
  renderFriends();
}

async function sendFriendRequest(targetId, eventId = null) {
  if (!uuidPattern.test(targetId) || targetId === user.id) return;
  const existing = friendships.find((row) => (row.requester_id === user.id && row.addressee_id === targetId) || (row.requester_id === targetId && row.addressee_id === user.id));
  if (existing?.status === 'accepted') { toast('Ya son amigos en DoIT.'); return; }
  if (existing?.requester_id === targetId && existing?.addressee_id === user.id && existing.status === 'pending') {
    const { error } = await sb.from('friendships').update({ status: 'accepted', updated_at: new Date().toISOString() }).eq('id', existing.id);
    if (error) throw error;
    await refreshFriendships();
    toast('¡Ahora son amigos en DoIT!');
    return;
  }
  if (existing?.requester_id === user.id && existing.status === 'pending') { toast('Ya enviaste una solicitud a esta persona.'); return; }
  if (existing?.status === 'rejected') {
    const { error: deleteError } = await sb.from('friendships').delete().eq('id', existing.id);
    if (deleteError) throw deleteError;
  }
  const { error } = await sb.from('friendships').insert({ requester_id: user.id, addressee_id: targetId, status: 'pending', source_event_id: eventId });
  if (error) throw error;
  await refreshFriendships();
  toast('Solicitud de amistad enviada. La otra persona debe aceptarla.');
}

async function processEventInvite() {
  const params = new URL(location.href).searchParams;
  const inviteToken = params.get('invite');
  let eventId = params.get('event');
  let inviterId = null;
  let inviteFromToken = null;
  if (inviteToken) {
    if (!uuidPattern.test(inviteToken)) return;
    const { data: resolved, error: resolveError } = await sb.rpc('resolve_event_invite', { p_token: inviteToken });
    if (resolveError) throw resolveError;
    const inviteRecord = Array.isArray(resolved) ? resolved[0] : resolved;
    if (!inviteRecord?.event_id || !uuidPattern.test(inviteRecord.event_id)) {
      $('eventInviteNotice').classList.remove('hidden');
      $('eventInviteNotice').textContent = 'Este enlace de invitación no es válido o el plan ya no está disponible.';
      return;
    }
    eventId = inviteRecord.event_id;
    inviterId = inviteRecord.inviter_id;
    // The signed-in invitee receives only the plan bound to this bearer token.
    // Do not perform a second broad events-table lookup for an invite token.
    inviteFromToken = {
      id: inviteRecord.event_id,
      creator_id: inviteRecord.creator_id,
      group_id: inviteRecord.group_id,
      title: inviteRecord.title,
      description: inviteRecord.description,
      date_time: inviteRecord.date_time,
      location: inviteRecord.location,
      category: inviteRecord.category
    };
  }
  if (!eventId || !uuidPattern.test(eventId)) return;
  let invite = inviteFromToken || events.find((row) => row.id === eventId);
  if (!invite && !inviteToken) {
    const { data, error } = await sb.from('events').select('id,creator_id,group_id,title,description,date_time,location,category').eq('id', eventId).maybeSingle();
    if (error) throw error;
    invite = data;
  }
  if (!invite) {
    $('eventInviteNotice').classList.remove('hidden');
    $('eventInviteNotice').textContent = 'El plan compartido ya no está disponible.';
    return;
  }
  // The signed token resolves the actual account that shared the plan. Legacy links use its creator.
  eventInvite = { event: invite, inviterId: uuidPattern.test(inviterId || '') ? inviterId : invite.creator_id };
  let inviterName = 'La persona que te invitó';
  if (eventInvite.inviterId !== user.id) {
    const cached = friendProfiles.get(eventInvite.inviterId);
    if (cached?.full_name) inviterName = cached.full_name;
    else {
      const { data } = await sb.from('profiles').select('id,full_name,avatar_url').eq('id', eventInvite.inviterId).maybeSingle();
      if (data?.full_name) inviterName = data.full_name;
    }
  }
  const existingFriendship = friendships.find((row) => (row.requester_id === eventInvite.inviterId && row.addressee_id === user.id) || (row.requester_id === user.id && row.addressee_id === eventInvite.inviterId));
  const outgoingPending = existingFriendship?.status === 'pending' && existingFriendship.requester_id === user.id;
  const friendButton = eventInvite.inviterId !== user.id && existingFriendship?.status !== 'accepted'
    ? `<button class="small-btn primary" data-action="invite-friend" data-id="${escapeHTML(eventInvite.inviterId)}" data-event-id="${escapeHTML(invite.id)}" ${outgoingPending ? 'disabled' : ''}>${outgoingPending ? 'Solicitud enviada' : 'Conectar con quien te invitó'}</button>`
    : '<span class="tag">Ya tienen conexión</span>';
  $('eventInviteNotice').innerHTML = `<h3>Te invitaron a un plan</h3><p>${escapeHTML(inviterName)} compartió esta actividad contigo. Puedes confirmar tu asistencia y enviar una solicitud de amistad.</p>${eventCard(invite)}<div class="card-actions">${friendButton}</div>`;
  $('eventInviteNotice').classList.remove('hidden');
  setTab('plans');
}

async function rsvp(eventId, status) {
  try {
    const { error } = await sb.from('event_attendees').upsert({ event_id: eventId, user_id: user.id, status }, { onConflict: 'event_id,user_id' });
    if (error) throw error;
    const existing = attendees.find((row) => row.event_id === eventId && row.user_id === user.id);
    if (existing) existing.status = status;
    else attendees.push({ event_id: eventId, user_id: user.id, status });
    renderEvents();
    toast('Tu respuesta quedó guardada.');
  } catch (error) { toast(error.message); }
}

async function joinGroup(groupId) {
  try {
    const { error } = await sb.from('group_members').insert({ group_id: groupId, user_id: user.id });
    if (error && error.code !== '23505') throw error;
    if (!groupMembers.some((row) => row.group_id === groupId && row.user_id === user.id)) groupMembers.push({ group_id: groupId, user_id: user.id });
    renderGroups();
    toast('Te uniste al grupo.');
  } catch (error) { toast(error.message); }
}

async function acceptFriendRequest(id) {
  const { error } = await sb.from('friendships').update({ status: 'accepted', updated_at: new Date().toISOString() }).eq('id', id).eq('addressee_id', user.id);
  if (error) throw error;
  await refreshFriendships();
  toast('¡Ahora son amigos en DoIT!');
}

async function rejectFriendRequest(id) {
  const { error } = await sb.from('friendships').update({ status: 'rejected', updated_at: new Date().toISOString() }).eq('id', id).eq('addressee_id', user.id);
  if (error) throw error;
  await refreshFriendships();
  toast('Solicitud descartada.');
}

async function loadChats() {
  if (!user) return;
  const { data: memberRows, error: memberError } = await sb.from('conversation_members').select('conversation_id,user_id');
  if (memberError) throw memberError;
  conversationMembers = memberRows || [];
  const conversationIds = [...new Set(conversationMembers.map((row) => row.conversation_id))];
  if (!conversationIds.length) {
    conversations = [];
    directory = new Map();
    renderConversationList();
    return;
  }
  const otherIds = [...new Set(conversationMembers.filter((row) => row.user_id !== user.id).map((row) => row.user_id))];
  const [conversationResult, profileResult] = await Promise.all([
    sb.from('conversations').select('id,direct_key,created_at,last_message_at').in('id', conversationIds).order('last_message_at', { ascending: false }),
    otherIds.length ? sb.from('profiles').select('id,full_name,avatar_url,bio').in('id', otherIds) : Promise.resolve({ data: [], error: null })
  ]);
  if (conversationResult.error) throw conversationResult.error;
  if (profileResult.error) throw profileResult.error;
  directory = new Map((profileResult.data || []).map((row) => [row.id, row]));
  conversations = (conversationResult.data || []).map((conversation) => {
    const peer = conversationMembers.find((row) => row.conversation_id === conversation.id && row.user_id !== user.id);
    return { ...conversation, peerId: peer?.user_id, peer: peer ? directory.get(peer.user_id) : null };
  }).filter((conversation) => conversation.peerId);
  renderConversationList();
  if (activeConversationId && !conversationIds.includes(activeConversationId)) {
    activeConversationId = null;
    closeActiveChannel();
    $('activeChat').classList.add('hidden');
    $('chatEmpty').classList.remove('hidden');
  }
}

function avatarMarkup(profileRow) {
  const name = profileRow?.full_name || 'Doit';
  if (profileRow?.avatar_url && /^https:\/\//i.test(profileRow.avatar_url)) {
    return `<div class="avatar"><img src="${escapeHTML(profileRow.avatar_url)}" alt=""></div>`;
  }
  return `<div class="avatar">${escapeHTML(name.trim().charAt(0).toUpperCase() || 'D')}</div>`;
}

function renderConversationList() {
  const container = $('conversationList');
  if (!conversations.length) {
    container.innerHTML = '<p class="empty-hint">Tus chats aparecerán aquí cuando empieces a hablar con alguien.</p>';
    return;
  }
  container.innerHTML = conversations.map((conversation) => `
    <button class="conversation-row ${conversation.id === activeConversationId ? 'active' : ''}" type="button" data-action="open-chat" data-id="${escapeHTML(conversation.id)}">
      ${avatarMarkup(conversation.peer)}<span><strong>${escapeHTML(conversation.peer?.full_name || 'Usuario Doit')}</strong><small>Chat privado</small></span>
    </button>`).join('');
}

async function searchUsers(query) {
  const term = query.trim().replace(/[%_]/g, '');
  if (term.length < 2) {
    $('userResults').innerHTML = '<p class="empty-hint">Escribe al menos 2 letras para buscar.</p>';
    return;
  }
  const { data, error } = await sb.from('profiles').select('id,full_name,avatar_url,bio').neq('id', user.id).ilike('full_name', `%${term}%`).limit(20);
  if (error) throw error;
  const users = data || [];
  $('userResults').innerHTML = users.length ? users.map((row) => `
    <button class="user-result" type="button" data-action="start-chat" data-id="${escapeHTML(row.id)}">
      ${avatarMarkup(row)}<span><strong>${escapeHTML(row.full_name || 'Usuario Doit')}</strong><small>Enviar mensaje</small></span>
    </button>`).join('') : '<p class="empty-hint">No encontramos personas con ese nombre.</p>';
}

async function startDirectConversation(targetUserId) {
  if (!uuidPattern.test(targetUserId) || targetUserId === user.id) return;
  // Create the direct conversation and both memberships atomically on the server.
  // This avoids half-created chats when two users click at the same time or a request drops.
  const { data: conversationId, error } = await sb.rpc('start_direct_conversation', { p_peer_id: targetUserId });
  if (error) throw error;
  if (!uuidPattern.test(String(conversationId || ''))) throw new Error('No fue posible abrir la conversación. Intenta de nuevo.');
  await loadChats();
  setTab('chat');
  await openConversation(conversationId);
  $('userSearch').value = '';
  $('userResults').innerHTML = '<p class="empty-hint">Busca a otra persona cuando quieras iniciar un chat.</p>';
}

function closeActiveChannel() {
  if (activeChannel && sb) sb.removeChannel(activeChannel).catch(() => {});
  activeChannel = null;
}

async function subscribeGlobalActivity() {
  if (!sb || globalChannel) return;
  await sb.realtime.setAuth();
  const channel = sb.channel('doit-global-activity');
  channel.on('postgres_changes', { event: '*', schema: 'public', table: 'events' }, (change) => {
    const record = change.new || change.old;
    if (!record?.id) return;
    if (change.eventType === 'DELETE') events = events.filter((row) => row.id !== record.id);
    else if (new Date(record.date_time) > new Date()) {
      const index = events.findIndex((row) => row.id === record.id);
      if (index >= 0) events[index] = { ...events[index], ...record };
      else events.unshift(record);
    }
    renderEvents();
  });
  channel.on('postgres_changes', { event: '*', schema: 'public', table: 'groups' }, (change) => {
    const record = change.new || change.old;
    if (!record?.id) return;
    if (change.eventType === 'DELETE') groups = groups.filter((row) => row.id !== record.id);
    else {
      const index = groups.findIndex((row) => row.id === record.id);
      if (index >= 0) groups[index] = { ...groups[index], ...record };
      else groups.unshift(record);
    }
    renderGroups();
    renderAll();
  });
  channel.on('postgres_changes', { event: '*', schema: 'public', table: 'group_members' }, (change) => {
    const record = change.new || change.old;
    if (!record?.group_id || !record?.user_id) return;
    if (change.eventType === 'DELETE') groupMembers = groupMembers.filter((row) => !(row.group_id === record.group_id && row.user_id === record.user_id));
    else if (!groupMembers.some((row) => row.group_id === record.group_id && row.user_id === record.user_id)) groupMembers.push(record);
    renderGroups();
    const selected = $('eventGroup').value;
    renderAll();
    $('eventGroup').value = selected;
  });
  channel.on('postgres_changes', { event: '*', schema: 'public', table: 'event_attendees' }, (change) => {
    const record = change.new || change.old;
    if (!record?.event_id || !record?.user_id) return;
    const index = attendees.findIndex((row) => row.event_id === record.event_id && row.user_id === record.user_id);
    if (change.eventType === 'DELETE') {
      if (index >= 0) attendees.splice(index, 1);
    } else if (index >= 0) attendees[index] = { ...attendees[index], ...record };
    else attendees.push(record);
    renderEvents();
  });
  channel.on('postgres_changes', { event: '*', schema: 'public', table: 'conversation_members' }, (change) => {
    const record = change.new || change.old;
    if (!record?.conversation_id || record.user_id !== user?.id) return;
    loadChats().catch((error) => toast(error.message));
  });
  channel.on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, (change) => {
    const record = change.new;
    if (!record?.conversation_id || record.sender_id === user?.id) return;
    const conversation = conversations.find((row) => row.id === record.conversation_id);
    if (!conversation) return;
    conversation.last_message_at = record.created_at;
    conversations.sort((a, b) => new Date(b.last_message_at) - new Date(a.last_message_at));
    renderConversationList();
  });
  globalChannel = channel;
  channel.subscribe();
}

function renderMessages() {
  const container = $('chatMessages');
  if (!chatMessages.length) {
    container.innerHTML = '<p class="empty-hint">Saluda y empieza la conversación.</p>';
    return;
  }
  container.innerHTML = chatMessages.map((message) => {
    const mine = message.sender_id === user.id;
    const time = new Intl.DateTimeFormat('es-CO', { hour: '2-digit', minute: '2-digit' }).format(new Date(message.created_at));
    return `<article class="message ${mine ? 'mine' : 'theirs'}"><p>${escapeHTML(message.body)}</p><time>${escapeHTML(time)}</time></article>`;
  }).join('');
  container.scrollTop = container.scrollHeight;
}

function addIncomingMessage(record) {
  if (!record || record.conversation_id !== activeConversationId || !record.id) return;
  if (chatMessages.some((message) => message.id === record.id)) return;
  chatMessages.push(record);
  chatMessages.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
  renderMessages();
  const current = conversations.find((row) => row.id === activeConversationId);
  if (current) {
    current.last_message_at = record.created_at;
    conversations.sort((a, b) => new Date(b.last_message_at) - new Date(a.last_message_at));
    renderConversationList();
  }
}

async function fetchConversationMessages(conversationId) {
  const { data, error } = await sb.from('messages').select('id,conversation_id,sender_id,body,created_at')
    .eq('conversation_id', conversationId).order('created_at', { ascending: true }).limit(100);
  if (error) throw error;
  if (activeConversationId !== conversationId) return;
  chatMessages = data || [];
  renderMessages();
}

async function openConversation(conversationId) {
  if (!uuidPattern.test(conversationId)) return;
  const isMember = conversationMembers.some((row) => row.conversation_id === conversationId && row.user_id === user.id);
  if (!isMember) throw new Error('No tienes acceso a esta conversación.');
  closeActiveChannel();
  activeConversationId = conversationId;
  const selected = conversations.find((row) => row.id === conversationId);
  $('chatName').textContent = selected?.peer?.full_name || 'Usuario Doit';
  $('chatAvatar').textContent = (selected?.peer?.full_name || 'D').trim().charAt(0).toUpperCase();
  if (selected?.peer?.avatar_url && /^https:\/\//i.test(selected.peer.avatar_url)) {
    $('chatAvatar').innerHTML = `<img src="${escapeHTML(selected.peer.avatar_url)}" alt="">`;
  }
  $('chatStatus').textContent = 'Chat privado · solo participantes';
  $('chatEmpty').classList.add('hidden');
  $('activeChat').classList.remove('hidden');
  renderConversationList();
  await fetchConversationMessages(conversationId);
  await sb.realtime.setAuth();
  const channel = sb.channel(`conversation:${conversationId}`, { config: { private: true } });
  channel.on('broadcast', { event: 'INSERT' }, (event) => {
    const payload = event?.payload || {};
    addIncomingMessage(payload.record || payload.new || payload);
  });
  activeChannel = channel;
  channel.subscribe((status) => {
    if (status === 'SUBSCRIBED' && activeConversationId === conversationId) {
      fetchConversationMessages(conversationId).catch((error) => toast(error.message));
    }
  });
}

async function sendMessage(event) {
  event.preventDefault();
  const body = $('chatInput').value.trim();
  if (!body || !activeConversationId || !user) return;
  $('sendMessage').disabled = true;
  try {
    const { data, error } = await sb.from('messages').insert({ conversation_id: activeConversationId, sender_id: user.id, body })
      .select('id,conversation_id,sender_id,body,created_at').single();
    if (error) throw error;
    $('chatInput').value = '';
    addIncomingMessage(data);
    // Push is best-effort; the durable private chat message is already stored in Supabase.
    const { data: sessionData } = await sb.auth.getSession();
    const accessToken = sessionData?.session?.access_token;
    if (accessToken) {
      fetch('/api/push/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${accessToken}` },
        body: JSON.stringify({ message_id: data.id })
      }).catch(() => {});
    }
    await loadChats();
  } catch (error) { toast(error.message); }
  finally { $('sendMessage').disabled = false; $('chatInput').focus(); }
}

function base64UrlToUint8Array(value) {
  const padding = '='.repeat((4 - value.length % 4) % 4);
  const base64 = (value + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  return Uint8Array.from([...raw].map((char) => char.charCodeAt(0)));
}

async function updatePushButton() {
  if (config?.pushReady !== true || !serviceWorkerRegistration || !('PushManager' in window)) {
    $('pushToggle').textContent = 'Notificaciones no configuradas';
    $('pushToggle').disabled = true;
    updatePushOnboarding();
    return;
  }
  const subscription = await serviceWorkerRegistration.pushManager.getSubscription();
  pushEnabled = !!subscription;
  $('pushToggle').textContent = pushEnabled ? 'Desactivar notificaciones' : 'Activar notificaciones';
  $('pushToggle').disabled = false;
  updatePushOnboarding();
}

async function togglePush() {
  try {
    if (config?.pushReady !== true) throw new Error('Las notificaciones todavía no están configuradas en el servidor. Puedes instalar DoIT desde el botón superior.');
    if (!('Notification' in window) || !('serviceWorker' in navigator) || !('PushManager' in window)) {
      throw new Error('Este navegador no admite notificaciones push.');
    }
    if (isIOSDevice() && !isAppInstalled()) {
      throw new Error('En iPhone o iPad, primero instala DoIT desde Safari: Compartir → Añadir a pantalla de inicio. Después abre el icono y activa las notificaciones.');
    }
    if (!serviceWorkerRegistration) await navigator.serviceWorker.register('/sw.js');
    serviceWorkerRegistration = await navigator.serviceWorker.ready;
    const current = await serviceWorkerRegistration.pushManager.getSubscription();
    if (current) {
      const { error } = await sb.from('push_subscriptions').delete().eq('endpoint', current.endpoint);
      if (error) throw error;
      await current.unsubscribe();
      pushEnabled = false;
      await updatePushButton();
      toast('Notificaciones desactivadas en este dispositivo.');
      return;
    }
    let permission = Notification.permission;
    if (permission === 'default') permission = await Notification.requestPermission();
    if (permission !== 'granted') throw new Error('No se concedió permiso para mostrar notificaciones.');
    const subscription = await serviceWorkerRegistration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: base64UrlToUint8Array(config.pushPublicKey)
    });
    const serialized = subscription.toJSON();
    const keys = serialized.keys || {};
    const { error } = await sb.from('push_subscriptions').upsert({
      user_id: user.id,
      endpoint: serialized.endpoint,
      p256dh: keys.p256dh,
      auth: keys.auth,
      expiration_time: serialized.expirationTime || null
    }, { onConflict: 'endpoint' });
    if (error) {
      await subscription.unsubscribe();
      throw error;
    }
    pushEnabled = true;
    await updatePushButton();
    sessionStorage.removeItem('doit-push-onboarding-dismissed');
    toast('Notificaciones activadas en este dispositivo.');
  } catch (error) { toast(error.message); }
}

async function removeCurrentPushSubscription() {
  try {
    const registration = serviceWorkerRegistration || await navigator.serviceWorker.getRegistration('/');
    const subscription = await registration?.pushManager?.getSubscription();
    if (!subscription) return;
    await sb.from('push_subscriptions').delete().eq('endpoint', subscription.endpoint);
    await subscription.unsubscribe();
  } catch (_) { /* Sign-out should remain available even if push cleanup fails. */ }
}

async function initializeServiceWorker() {
  if ('serviceWorker' in navigator && location.protocol === 'https:') {
    try {
      await navigator.serviceWorker.register('/sw.js');
      serviceWorkerRegistration = await navigator.serviceWorker.ready;
      return serviceWorkerRegistration;
    } catch (error) { console.warn('Service worker registration failed:', error.message); }
  }
  return null;
}

async function initialize() {
  updateInstallCard();
  $('installAppBtn').addEventListener('click', handleInstallClick);
  $('enablePushOnboarding').addEventListener('click', togglePush);
  $('dismissPushOnboarding').addEventListener('click', () => {
    sessionStorage.setItem('doit-push-onboarding-dismissed', '1');
    updatePushOnboarding();
  });
  try {
    const response = await fetch('/api/config', { cache: 'no-store' });
    if (!response.ok) throw new Error('No fue posible cargar la configuración de Doit.');
    config = await response.json();
    if (!window.supabase?.createClient) throw new Error('No se pudo cargar el cliente de Supabase.');
    sb = window.supabase.createClient(config.supabaseUrl, config.supabasePublishableKey, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    });
    $('cloudState').textContent = 'Conectado';
    await initializeServiceWorker();
    const { data, error } = await sb.auth.getSession();
    if (error) throw error;
    user = data.session?.user || null;
    if (user) await loadData(); else showAuth();
    sb.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_OUT') {
        user = null;
        profile = null;
        conversations = [];
        closeActiveChannel();
        if (globalChannel && sb) sb.removeChannel(globalChannel).catch(() => {});
        globalChannel = null;
        showAuth();
      } else if (session?.user && ['SIGNED_IN', 'TOKEN_REFRESHED', 'USER_UPDATED'].includes(event)) {
        user = session.user;
        Promise.resolve().then(() => loadData()).catch((error) => toast(error.message));
      }
    });
  } catch (error) {
    $('cloudState').textContent = 'Sin conexión';
    $('authError').innerHTML = `<div class="status-error">${escapeHTML(error.message)} El acceso y el registro permanecen desactivados hasta restablecer la conexión.</div>`;
    showAuth();
  }
}

// Auth
function selectedSignupInterests() {
  return [...document.querySelectorAll('input[name="signupInterest"]:checked')].map((input) => input.value);
}

function splitHobbies(value) {
  return [...new Set(String(value || '').split(',').map((item) => item.trim()).filter(Boolean))].slice(0, 20);
}

$('authForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('authSubmit').disabled = true;
  $('authError').textContent = '';
  try {
    const email = $('email').value.trim();
    const password = $('password').value;
    if (password.length < 8) throw new Error('La contraseña debe tener al menos 8 caracteres.');
    if (loginMode) {
      const { error } = await sb.auth.signInWithPassword({ email, password });
      if (error) throw error;
    } else {
      const fullName = $('fullName').value.trim();
      const countryCode = $('signupCountry').value;
      const city = $('signupCity').value.trim();
      const interests = selectedSignupInterests();
      const hobbies = splitHobbies($('signupHobbies').value);
      if (!fullName) throw new Error('Escribe tu nombre.');
      if (!countryCode || !city) throw new Error('Selecciona tu país y escribe tu ciudad.');
      if (!interests.length) throw new Error('Selecciona al menos un interés.');
      const country = profileCountryName(countryCode);
      const weeklyTimeMinutes = Number($('signupWeeklyTime').value) || 180;
      const discoverable = $('signupDiscoverable').checked;
      const { data, error } = await sb.auth.signUp({
        email,
        password,
        options: { data: {
          full_name: fullName,
          country_code: countryCode,
          country,
          city,
          interests,
          hobbies,
          weekly_time_minutes: weeklyTimeMinutes,
          discoverable
        } }
      });
      if (error) throw error;
      if (!data.session || !data.user) {
        $('authError').innerHTML = '<div class="status-error">Supabase todavía exige confirmar el correo. Para habilitar el ingreso inmediato, desactiva “Confirm email” en Authentication → Providers → Email. Las preferencias quedan vinculadas a la cuenta y se guardarán al iniciar sesión.</div><a class="auth-settings-link" href="https://supabase.com/dashboard/project/pvtwpvlrvlezsxnvublz/auth/providers" target="_blank" rel="noopener noreferrer">Abrir ajustes de autenticación</a>';
        return;
      }
      user = data.user;
      await loadData();
      toast('¡Cuenta creada! Ya estás dentro de DoIT.');
    }
  } catch (error) {
    $('authError').innerHTML = `<div class="status-error">${escapeHTML(error.message)}</div>`;
  } finally { $('authSubmit').disabled = false; }
});
$('switchAuth').addEventListener('click', () => {
  loginMode = !loginMode;
  $('nameField').classList.toggle('hidden', loginMode);
  $('fullName').required = !loginMode;
  $('signupPreferences').classList.toggle('hidden', loginMode);
  $('signupCountry').required = !loginMode;
  $('signupCity').required = !loginMode;
  $('authTitle').textContent = loginMode ? 'Bienvenido de nuevo' : 'Crea tu cuenta';
  $('authSubtitle').textContent = loginMode ? 'Entra para revisar tus planes y comunidades.' : 'Encuentra personas, organiza planes y crea conexiones reales.';
  $('authSubmit').textContent = loginMode ? 'Iniciar sesión' : 'Crear cuenta';
  $('switchAuth').textContent = loginMode ? '¿No tienes cuenta? Crear una' : '¿Ya tienes cuenta? Iniciar sesión';
  $('authError').textContent = '';
});

// App navigation and event actions
document.querySelectorAll('.nav-button').forEach((button) => button.addEventListener('click', () => setTab(button.dataset.tab)));
document.addEventListener('click', async (event) => {
  const agendaDateButton = event.target.closest('[data-agenda-date]');
  if (agendaDateButton) {
    agendaDate = parseDateKey(agendaDateButton.dataset.agendaDate);
    agendaView = 'day';
    renderAgenda();
    return;
  }
  const button = event.target.closest('[data-action]');
  if (!button || button.disabled) return;
  const action = button.dataset.action;
  const id = button.dataset.id;
  try {
    if (action === 'rsvp') await rsvp(id, button.dataset.status);
    else if (action === 'join-group') await joinGroup(id);
    else if (action === 'start-chat') await startDirectConversation(id);
    else if (action === 'open-chat') await openConversation(id);
    else if (action === 'copy-event-link') {
      const plan = events.find((row) => row.id === id) || eventInvite?.event;
      if (!plan) throw new Error('No se encontró el plan.');
      const inviteUrl = await getEventShareUrl(plan);
      try { await navigator.clipboard.writeText(inviteUrl); }
      catch (_) {
        const temp = document.createElement('textarea'); temp.value = inviteUrl; document.body.appendChild(temp); temp.select();
        const copied = document.execCommand('copy'); temp.remove(); if (!copied) throw new Error('No se pudo copiar el enlace.');
      }
      toast('Enlace copiado. Envíalo para que se registren y vean el plan.');
    } else if (action === 'invite-friend') await sendFriendRequest(id, button.dataset.eventId || null);
    else if (action === 'accept-friend') await acceptFriendRequest(id);
    else if (action === 'reject-friend') await rejectFriendRequest(id);
  } catch (error) { toast(error.message); }
});

$('agendaPrev').addEventListener('click', () => {
  if (agendaView === 'month') agendaDate = new Date(agendaDate.getFullYear(), agendaDate.getMonth() - 1, 1);
  else if (agendaView === 'week') agendaDate = moveDate(agendaDate, -7);
  else agendaDate = moveDate(agendaDate, -1);
  renderAgenda();
});
$('agendaNext').addEventListener('click', () => {
  if (agendaView === 'month') agendaDate = new Date(agendaDate.getFullYear(), agendaDate.getMonth() + 1, 1);
  else if (agendaView === 'week') agendaDate = moveDate(agendaDate, 7);
  else agendaDate = moveDate(agendaDate, 1);
  renderAgenda();
});
$('agendaToday').addEventListener('click', () => { agendaDate = new Date(); renderAgenda(); });
document.querySelectorAll('[data-agenda-view]').forEach((button) => button.addEventListener('click', () => {
  agendaView = button.dataset.agendaView;
  renderAgenda();
}));

$('eventForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('eventSubmit').disabled = true;
  try {
    const dateTime = new Date(`${$('eventDate').value}T${$('eventTime').value}:00`);
    if (!Number.isFinite(dateTime.getTime()) || dateTime <= new Date()) throw new Error('Selecciona una fecha y hora futuras.');
    const { data, error } = await sb.from('events').insert({
      creator_id: user.id,
      group_id: $('eventGroup').value || null,
      title: $('eventTitle').value.trim(),
      description: $('eventDescription').value.trim() || null,
      date_time: dateTime.toISOString(),
      location: $('eventLocation').value.trim(),
      category: $('eventCategory').value,
      reminder_preference: '1h'
    }).select('id,creator_id,group_id,title,description,date_time,location,category').single();
    if (error) throw error;
    const { error: attendeeError } = await sb.from('event_attendees').upsert({ event_id: data.id, user_id: user.id, status: 'voy' }, { onConflict: 'event_id,user_id' });
    if (attendeeError) throw attendeeError;
    events.unshift(data);
    attendees.push({ event_id: data.id, user_id: user.id, status: 'voy' });
    $('eventForm').reset();
    renderAll();
    setTab('plans');
    toast('Tu plan ya está publicado.');
  } catch (error) { toast(error.message); }
  finally { $('eventSubmit').disabled = false; }
});

$('groupForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = $('groupForm').querySelector('button[type="submit"]');
  button.disabled = true;
  try {
    const interestTags = splitHobbies($('groupInterestTags').value);
    const { data, error } = await sb.from('groups').insert({
      creator_id: user.id,
      name: $('groupName').value.trim(),
      description: $('groupDescription').value.trim() || null,
      category: 'general',
      icon: 'diversity_2',
      country_code: profilePreferences?.country_code || null,
      city: profilePreferences?.city || null,
      interest_tags: interestTags
    }).select('id,creator_id,name,description,category,icon,country_code,city,interest_tags').single();
    if (error) throw error;
    groups.unshift(data);
    groupMembers.push({ group_id: data.id, user_id: user.id });
    $('groupForm').reset();
    renderAll();
    toast('Grupo creado.');
  } catch (error) { toast(error.message); }
  finally { button.disabled = false; }
});

$('chatComposer').addEventListener('submit', sendMessage);
$('userSearch').addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => searchUsers($('userSearch').value).catch((error) => toast(error.message)), 280);
});
$('pushToggle').addEventListener('click', togglePush);
$('usageLimit').addEventListener('input', () => { $('limitValue').textContent = `${$('usageLimit').value} min`; });
$('saveProfile').addEventListener('click', async () => {
  try {
    const name = $('profileName').value.trim();
    const countryCode = $('profileCountry').value;
    const city = $('profileCity').value.trim();
    const interests = [...document.querySelectorAll('input[name="profileInterest"]:checked')].map((input) => input.value);
    const hobbies = splitHobbies($('profileHobbies').value);
    if (!name) throw new Error('Escribe un nombre.');
    if (!countryCode || !city) throw new Error('Selecciona tu país y escribe tu ciudad.');
    if (!interests.length) throw new Error('Selecciona al menos un interés.');
    const { error: profileError } = await sb.from('profiles').update({ full_name: name, usage_limit_mins: Number($('usageLimit').value) }).eq('id', user.id);
    if (profileError) throw profileError;
    const { error: preferencesError } = await sb.from('profile_preferences').upsert({
      user_id: user.id, country_code: countryCode, country: profileCountryName(countryCode), city,
      interests, hobbies, weekly_time_minutes: Number($('profileWeeklyTime').value) || 180,
      discoverable: $('profileDiscoverable').checked, onboarding_completed: true, updated_at: new Date().toISOString()
    }, { onConflict: 'user_id' });
    if (preferencesError) throw preferencesError;
    const { error: groupsLocationError } = await sb.from('groups').update({ country_code: countryCode, city }).eq('creator_id', user.id);
    if (groupsLocationError) throw groupsLocationError;
    profile.full_name = name;
    profile.usage_limit_mins = Number($('usageLimit').value);
    profilePreferences = { ...profilePreferences, country_code: countryCode, country: profileCountryName(countryCode), city,
      interests, hobbies, weekly_time_minutes: Number($('profileWeeklyTime').value) || 180,
      discoverable: $('profileDiscoverable').checked, onboarding_completed: true };
    groups = groups.map((group) => group.creator_id === user.id ? { ...group, country_code: countryCode, city } : group);
    await syncProfileDiscovery(profilePreferences);
    await loadNearbyPeople();
    showApp();
    renderAll();
    toast('Perfil y preferencias actualizados.');
  } catch (error) { toast(error.message); }
});

$('chooseAvatar').addEventListener('click', () => $('avatarFile').click());
$('avatarFile').addEventListener('change', async () => {
  const file = $('avatarFile').files?.[0];
  if (!file) return;
  try {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw new Error('Usa una imagen JPG, PNG o WebP.');
    if (file.size > 3 * 1024 * 1024) throw new Error('La foto debe pesar máximo 3 MB.');
    const extension = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
    const objectPath = `${user.id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${extension}`;
    const { error: uploadError } = await sb.storage.from('avatars').upload(objectPath, file, { contentType: file.type, cacheControl: '3600', upsert: false });
    if (uploadError) throw uploadError;
    const { data: urlData } = sb.storage.from('avatars').getPublicUrl(objectPath);
    const { error: updateError } = await sb.from('profiles').update({ avatar_url: urlData.publicUrl }).eq('id', user.id);
    if (updateError) throw updateError;
    profile.avatar_url = urlData.publicUrl;
    showApp();
    await loadFriendProfiles();
    renderFriends();
    toast('Foto de perfil actualizada.');
  } catch (error) { toast(error.message); }
  finally { $('avatarFile').value = ''; }
});
$('signOut').addEventListener('click', async () => {
  closeActiveChannel();
  if (globalChannel && sb) sb.removeChannel(globalChannel).catch(() => {});
  globalChannel = null;
  await removeCurrentPushSubscription();
  const { error } = await sb.auth.signOut();
  if (error) toast(error.message);
  else { user = null; profile = null; profilePreferences = null; nearbyPeople = []; friendships = []; friendProfiles = new Map(); eventInvite = null; showAuth(); }
});

$('eventDate').min = localDateKey(new Date());
initialize();
